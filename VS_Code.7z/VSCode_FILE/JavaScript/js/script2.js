/** 兩數判斷 */
let a = 100
let b = 50
//condition = a>b
if (a > b) {
    console.log("a > b")
} else if( a < b){
    console.log("b > a")
} else{
    
}
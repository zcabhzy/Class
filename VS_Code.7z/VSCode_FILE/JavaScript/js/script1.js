
//let、var 有兩大使用方法
let a = 10
console.log(a>0)

let string = "Henry"
console.log(string)

let array = ["A","B","C","D","F"]
console.log(array)
console.log(array[0],array[4])
console.log("取第二筆資料 : ",array[1])

/** 物件型態 : 可以存放String,int,Array... */ 
const object ={
    yname : "Henry"
    ,yage : 26
    ,address:"Taiwan"
    ,array : ["AB","CD","EF","GH","IJ"]
}
console.log(object)

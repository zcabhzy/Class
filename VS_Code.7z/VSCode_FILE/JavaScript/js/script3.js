
/** switch 結構 */
let a = 5

switch(a){

    case 50:
        console.log(a)
    break
    case 50:
        console.log(a)
    break

    default:
        console.log("請確認數值是否有問題")
        break
    
}
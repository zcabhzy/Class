class func{
    constructor(newName){
        this.name = newName
    }
    start(){
        console.log("Hello Fucking Bitch~!")
    }
}

class Sun extends func{
    constructor(){
        super()
    }
}

const cs = new Sun()
cs.start()
function hello() {
    console.log(funtion)
}

function h1(a1,a2,a3){
    let resule = a1+a2+a3
    return resule
}

function card(initName){
    this.name = initName
}

const string = new card("My name is Henry")
console.log(string)
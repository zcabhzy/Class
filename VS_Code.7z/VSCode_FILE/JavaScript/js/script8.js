/** 彈跳視窗 */
//window.alert("你要進入網頁嗎")

window.addEventListener('load',function(){
    //console.log("I calling You")
    const call = this.document.getElementById("Title")
    call.innerText = "I calling You"

    const listener = this.document.getElementById("Button")
    listener.addEventListener('click',function(){
        console.log("Click Me")
    })

    const b2 = this.document.getElementById("box")
    b2.innerHTML="<h1> Hello!! </h1>"

    const c1 = this.document.getElementById("text")
    c1.addEventListener("Keyup",function(){
        console.log("text")
    })

})
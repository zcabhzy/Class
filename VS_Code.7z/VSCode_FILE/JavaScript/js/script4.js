/** for迴圈 */
let array = ["Henry","billy","kelly"]

for (let i = 0; i < array.length; i++) {
    
    console.log(array[i])
}